import { createContext } from "react";

const LoaderContext = createContext(null);

export default LoaderContext;