import React from 'react'
import TrainerDetail from '../../Components/TrainerDetail/TrainerDetail'

function AdminTrainerDetailPage() {
    return (
        <div>
            <TrainerDetail />
        </div>
    )
}

export default AdminTrainerDetailPage